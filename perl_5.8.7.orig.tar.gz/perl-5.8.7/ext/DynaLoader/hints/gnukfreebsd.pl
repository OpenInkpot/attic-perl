do './hints/linux.pl';
